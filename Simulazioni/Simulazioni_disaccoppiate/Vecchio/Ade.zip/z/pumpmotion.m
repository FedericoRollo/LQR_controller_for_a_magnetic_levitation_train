
%% Pump motion
% vertical motion (along z axes) is here analyzed. current 1 -> right front; 2 -> right center; 3-> right rear; 4 -> left front; 5 -> left center; 6 -> left rear   
clear all
clc

%% Constants
h = 10; %constant, height of z at rest
zi_rip = 3; %zi constant of zi when the train is at rest: graphically z(h)|zi(-zi_rest), where |->axes
xdot_ref = 10; % headway speed
m = 20;
radius = 0;
xB=1;
yB=1;
PHI=1;
PHIf=1;
PHIc=1;
PHIr=1;
mu0=1;
Nr=1;
Al=1;
rho=0.008;
Ss=1;
Cd=1;
Cl=1;
g=9.81;
R=1;
zB=1;
xA=1;
zA=1;
P1=10; 
P2=10;
P3=10; 
P4=10; 
P5=10; 
P6=10;
G1=10;
G2=10;
G3=10;
G4=10;
G5=10;
G6=10;
vx=1;
w=1;
l=1;
Jx=100;
Jy=100;

%% Differential equation definition
 
syms z zdot phi phidot theta thetadot ir1 ir2 ir3 ir4 ir5 ir6 qv vqv Vr1 Vr2 Vr3 Vr4 Vr5 Vr6 real

states = [z; zdot; phi; phidot; theta; thetadot; ir1; ir2; ir3; ir4; ir5; ir6];
inputs = [Vr1; Vr2; Vr3; Vr4; Vr5; Vr6];

% vertical displacements, measured by sensors
zFL = h + zi_rip -z - phi*yB + theta*xB; % - qv*PHI;
zCL = h + zi_rip -z - phi*yB; % - qv*PHI;
zRL = h + zi_rip -z - phi*yB - theta*xB; % - qv*PHI;
zFR = h + zi_rip -z + phi*yB + theta*xB; % - qv*PHI;
zCR = h + zi_rip -z + phi*yB; % - qv*PHI;
zRR = h + zi_rip -z + phi*yB - theta*xB; % - qv*PHI;

% vertical speed
zFL_dot = -zdot - phidot*yB + thetadot*xB; % - vqv*PHI;
zCL_dot = -zdot - phidot*yB; % - vqv*PHI;
zRL_dot = -zdot - phidot*yB - thetadot*xB; % - vqv*PHI;
zFR_dot = -zdot + phidot*yB + thetadot*xB; % - vqv*PHI;
zCR_dot = -zdot + phidot*yB; % - vqv*PHI;
zRR_dot = -zdot + phidot*yB - thetadot*xB; % - vqv*PHI;


% levitation forces
L1 = (mu0*Nr^2*Al/4)*(ir1/zFL)^2;
L2 = (mu0*Nr^2*Al/4)*(ir2/zCL)^2;
L3 = (mu0*Nr^2*Al/4)*(ir3/zRL)^2;
L4 = (mu0*Nr^2*Al/4)*(ir4/zFR)^2;
L5 = (mu0*Nr^2*Al/4)*(ir5/zCR)^2;
L6 = (mu0*Nr^2*Al/4)*(ir6/zRR)^2;

%{
%distribuzioni delle forze sul modello elastico
lf=(L1+L2-((rho*S*Cl/2)*(vx)^2+m*R*(wtheta^2)*sin(phi)+m*g*cos(phi))/3)/l;
lc=(L3+L4-((rho*S*Cl/2)*(vx)^2+m*R*(wtheta^2)*sin(phi)+m*g*cos(phi))/3)/l;
lr=(L5+L6-((rho*S*Cl/2)*(vx)^2+m*R*(wtheta^2)*sin(phi)+m*g*cos(phi))/3)/l;
%}

% diff equations
z_dot    = zdot;
zdot_dot = (L1 + L2 + L3 + L4 + L5 + L6 - (rho*Ss*Cl/2)*(xdot_ref)^2 - m*g*cos(phi) - m*radius*(thetadot^2)*sin(phi))/m;

phi_dot    = phidot;
phidot_dot = (yB*(L1 + L2 + L3 - L4 - L5 - L6) + zB*(G1 - G4 + G2 - G5 + G3 - G6))/Jx;

theta_dot    = thetadot;
thetadot_dot = (xB*(-L1 - L4 + L3 + L6) -zA*(rho*Ss*Cd/2)*(xdot_ref)^2 + xA*(rho*Ss*Cl/2)*(xdot_ref)^2)/Jy;

ir1_dot = (ir1/zFL)*zFL_dot -(2/(mu0*(Nr^2)*Al))*zFL*(R*ir1-Vr1);
ir2_dot = (ir2/zCL)*zCL_dot -(2/(mu0*(Nr^2)*Al))*zCL*(R*ir2-Vr2);
ir3_dot = (ir3/zRL)*zRL_dot -(2/(mu0*(Nr^2)*Al))*zRL*(R*ir3-Vr3);
ir4_dot = (ir4/zFR)*zFR_dot -(2/(mu0*(Nr^2)*Al))*zFR*(R*ir4-Vr4);
ir5_dot = (ir5/zCR)*zCR_dot -(2/(mu0*(Nr^2)*Al))*zCR*(R*ir5-Vr5);
ir6_dot = (ir6/zRR)*zRR_dot -(2/(mu0*(Nr^2)*Al))*zRR*(R*ir6-Vr6);

%{
%EQUAZIONI DEL MODELLO ELASTICO (per ora ne ho scritte solo due, poi vediamo)
qvdot=vqv;
vqvdot=-qv*w^2+lf*PHIf+lc*PHIc+lr*PHIr;
%}

%differential equation vector
ode = [z_dot zdot_dot phi_dot phidot_dot theta_dot thetadot_dot ir1_dot ir2_dot ir3_dot ir4_dot ir5_dot ir6_dot]';

% ode = transpose([zdot vzdot phidot wphidot thetadot wthetadot irdot1 irdot2 irdot3 irdot4 irdot5 irdot6]);

%% Linearization

% references
z_ref = 11;
zdot_ref = 0;
phi_ref = 0;
phidot_ref = 0;
theta_ref = 0;
thetadot_ref = 0;
zi_ref = h - z_ref +zi_rip;
iri_ref = sqrt( (1/(6*(mu0*Nr^2*Al/4)))*((rho*Ss*Cl/2)*(xdot_ref)^2 + m*g*cos(phi_ref) + m*radius*(thetadot_ref^2)*sin(phi_ref))*zi_ref^2);
ir1_ref = iri_ref;
ir2_ref = iri_ref;
ir3_ref = iri_ref;
ir4_ref = iri_ref;
ir5_ref = iri_ref;
ir6_ref = iri_ref;

Vr_ref = R*iri_ref;
Vr1_ref = Vr_ref;
Vr2_ref = Vr_ref;
Vr3_ref = Vr_ref;
Vr4_ref = Vr_ref;
Vr5_ref = Vr_ref;
Vr6_ref = Vr_ref;

format short;
A = jacobian(ode,states);
A = subs(A, {z zdot phi phidot theta thetadot ir1 ir2 ir3 ir4 ir5 ir6 Vr1 Vr2 Vr3 Vr4 Vr5 Vr6}, {z_ref zdot_ref phi_ref phidot_ref theta_ref thetadot_ref ir1_ref ir2_ref ir3_ref ir4_ref ir5_ref ir6_ref Vr1_ref Vr2_ref Vr3_ref Vr4_ref Vr5_ref Vr6_ref});
A = eval(A)
%A = vpa(A,5)

B = jacobian(ode,inputs);
B = subs(B,{theta phi z},{theta_ref phi_ref z_ref});
B = eval(B) 
%B = vpa(B, 5)

contr = ctrb(A,B);
r = rank(contr)


%% LQR control

Q = diag([100 1 10 1 10 1 1 1 1 1 1 1 ]);
% Q = diag([100 1 10 1 10 1 1 1 1 1 1 1 ]);
Rr = 1*eye(6);

K = lqr(A,B,Q,Rr);

xe = [z_ref zdot_ref phi_ref phidot_ref theta_ref thetadot_ref ir1_ref ir2_ref ir3_ref ir4_ref ir5_ref ir6_ref].';

%initial conditions for nonlinear sim
phi_init=0;
theta_init=0;